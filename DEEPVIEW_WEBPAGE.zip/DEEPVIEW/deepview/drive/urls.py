from django.urls import path
from . import views

urlpatterns = [
    path('', views.index2, name='index2'),
    path('request/', views.request, name='request'),
    path('about/', views.about, name='about'),
    path('automark/', views.automark, name='automark'),
]
