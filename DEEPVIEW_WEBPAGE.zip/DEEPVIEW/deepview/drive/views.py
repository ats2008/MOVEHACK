from django.shortcuts import render
from django.shortcuts import render
from django.http import HttpResponse, HttpResponseRedirect
from .models import *


def index2(request):
    return render(request,'drive/index2.html')

def request(request):
    return render(request,'drive/request.html')

def about(request):
    return HttpResponse("About us to Driver")

def automark(request):
    auto = autodb.objects.all()
    a={'num':[i.number  for i in auto],'lat':[i.latt for i in auto],'long':[i.long for i in auto]}
    return render(request, 'drive/automark.html',a)
