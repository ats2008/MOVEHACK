from django.apps import AppConfig


class DriveConfig(AppConfig):
    name = 'drive'
