from django.db import models
from django.contrib import admin
from django.contrib.auth.models import User
import csv
from django.http import HttpResponse

# Create your models here.
class autodb(models.Model):
    number = models.CharField(max_length=15)
    driverphone = models.CharField(max_length=10,default='9865322558')
    latt = models.FloatField(max_length=50)
    long = models.FloatField(max_length=50)
    availability = models.BooleanField(default=True)

class ExportCsvMixin:
    def export_as_csv(self, request, queryset):

        meta = self.model._meta
        field_names = [field.name for field in meta.fields]

        response = HttpResponse(content_type='text/csv')
        response['Content-Disposition'] = 'attachment; filename={}.csv'.format(meta)
        writer = csv.writer(response)

        writer.writerow(field_names)
        for obj in queryset:
            row = writer.writerow([getattr(obj, field) for field in field_names])

        return response
    export_as_csv.short_description = "Export Selected"

class autodbAdmin(admin.ModelAdmin,ExportCsvMixin):
    list_display = ('number', 'driverphone','latt','long','availability')
    actions = ["export_as_csv"]
