from django import forms
from .models import *

#origin-destination Form
class book_ride(forms.ModelForm):
    origin = forms.CharField(widget=forms.TextInput(
        attrs={
            'class':'form-control',
            'placeholder':'Enter pick-up location'
        }
    ), required=True, max_length=100)
    destination = forms.CharField(widget=forms.TextInput(
        attrs={
            'class':'form-control',
            'placeholder':'Enter drop-off location'
        }
    ), required=True)

    class Meta():
        model = bookride
        fields = ['origin','destination']


# feedback form
class feed_back(forms.ModelForm):
    starvalue = forms.IntegerField(widget=forms.TextInput(
        attrs={
            'class':'form-control',
            'placeholder':'Rate 1 - 5'
        }
    ), required=True)
    feedbacktext = forms.CharField(widget=forms.TextInput(
        attrs={
            'class':'form-control',
            'placeholder':'Enter Feedback...'
        }
    ),required=True, max_length=250)

    class Meta():
        model = feedback
        fields = ['starvalue','feedbacktext']
