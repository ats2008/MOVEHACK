from django.apps import AppConfig


class RideConfig(AppConfig):
    name = 'ride'
