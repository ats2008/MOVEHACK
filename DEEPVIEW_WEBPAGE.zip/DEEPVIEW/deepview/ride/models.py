from django.db import models
from django.contrib.auth.models import User
from django.contrib import admin
import csv
from django.http import HttpResponse


class bookride(models.Model):
    origin = models.CharField(max_length=150)
    destination = models.CharField(max_length=150)

class feedback(models.Model):
    starvalue = models.IntegerField()
    feedbacktext = models.CharField(max_length=300)

class ExportCsvMixin:
    def export_as_csv(self, request, queryset):

        meta = self.model._meta
        field_names = [field.name for field in meta.fields]

        response = HttpResponse(content_type='text/csv')
        response['Content-Disposition'] = 'attachment; filename={}.csv'.format(meta)
        writer = csv.writer(response)

        writer.writerow(field_names)
        for obj in queryset:
            row = writer.writerow([getattr(obj, field) for field in field_names])

        return response
    export_as_csv.short_description = "Export Selected"


class bookrideAdmin(admin.ModelAdmin,ExportCsvMixin):
    list_display = ('origin', 'destination')
    actions = ["export_as_csv"]

class feedbackAdmin(admin.ModelAdmin,ExportCsvMixin):
    list_display = ('starvalue', 'feedbacktext')
    actions = ["export_as_csv"]
