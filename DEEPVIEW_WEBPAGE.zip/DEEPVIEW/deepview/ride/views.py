from django.shortcuts import render
from django.http import HttpResponse, HttpResponseRedirect
from .forms import *
from .models import *


def index(request):
    if request.method == 'POST':
        form = book_ride(request.POST)
        if form.is_valid():
            form.save()
            a = bookride.objects.latest('id')
            mode = "DRIVING"
            # mode = "TRANSIT"
            # API_key = "AIzaSyDnkGvCnyNSW3bPrkHGPuE30xVN1bDsocM"
            args = {'orig':a.origin,'dest':a.destination,'mode':mode}
            return render(request, 'ride/map.html',args)

    else:
        form = book_ride()
    return render(request, 'ride/index.html',{'form':form})

def feedbackresult(request):
    if request.method == 'POST':
        form2 = feed_back(request.POST)
        if form2.is_valid():
            form2.save()
            fb = feedback.objects.latest('id')
            return render(request, 'ride/about.html')

    else:
        form2 = feed_back()
    return render(request, 'ride/feedback.html',{'form2':form2})

def process_url_from_client(request):
    url1 = request.POST.get('url')
    return HttpResponse(url1)

# def automark(request):
#     autodata = bookride.objects.
#     return render(request, 'ride/automark.html')

# 
# a={num:[b.num for b in auto],lat:[b.lat for b in auto]}
def about(request):
    return render(request, 'ride/about.html')

def map(request):
    return render(request, 'ride/map.html')

def terms(request):
    return render(request, 'ride/terms.html')

def flowchart(request):
    return render(request, 'ride/flowchart.html')

def submitted(request):
    return render(request, 'ride/submitted.html')
