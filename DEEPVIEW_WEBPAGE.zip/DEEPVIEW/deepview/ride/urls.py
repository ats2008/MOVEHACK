from django.urls import path
from . import views

urlpatterns = [
    path('', views.index, name='index'),
    path('about/', views.about, name='about'),
    path('terms/', views.terms, name='terms'),
    path('map/', views.map, name='map'),
    #path('flowy/', views.flowy, name='flowy'),
    path('flowchart/', views.flowchart, name='flowchart'),
    path('feedback/', views.feedbackresult, name='feedbackresult'),
    path('process_url_from_client/', views.process_url_from_client, name='process_url_from_client'),


]
