from django.contrib import admin
from .models import *
# from import_export.admin import ImportExportActionModelAdmin
# from import_export import resources

admin.site.register(bookride, bookrideAdmin)
admin.site.register(feedback,feedbackAdmin)


# class BookResource(resources.ModelResource):
#     class Meta:
#         model = bookride
#
# class BookAdmin(ImportExportActionModelAdmin):
#     resource_class = BookResource
