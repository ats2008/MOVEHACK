from django.contrib import admin
from django.urls import path, include

urlpatterns = [
    path('',include('ride.urls')),
    path('drive/',include('drive.urls')),
    path('admin/', admin.site.urls),
]
